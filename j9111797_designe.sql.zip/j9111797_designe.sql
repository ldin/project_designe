-- phpMyAdmin SQL Dump
-- version 4.5.3.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 25 2016 г., 11:27
-- Версия сервера: 5.6.28-76.1-beget-log
-- Версия PHP: 5.6.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `j9111797_designe`
--

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE `galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` smallint(6) NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `small_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent` smallint(6) NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `alt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sorted` smallint(6) NOT NULL,
  `noindex` tinyint(1) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `galleries`
--

INSERT INTO `galleries` (`id`, `post_id`, `slug`, `name`, `title`, `small_image`, `text`, `image`, `parent`, `tags`, `status`, `alt`, `sorted`, `noindex`, `description`, `keywords`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 35, '', '', '', 'upload/gallery/35/small/баня2.jpg', 'Дизайн бани.', 'upload/gallery/35/баня2.jpg', 0, '', 0, 'banya', 0, 0, '', '', NULL, '2015-12-11 05:38:49', '2015-12-22 12:01:44'),
(2, 35, '', '', '', 'upload/gallery/35/small/коридор.jpg', 'Дизайн коридора. Отель " Екатерина".', 'upload/gallery/35/коридор.jpg', 0, '', 0, 'koridor', 0, 0, '', '', NULL, '2015-12-11 05:40:11', '2015-12-22 12:01:36'),
(3, 35, '', '', '', 'upload/gallery/35/small/сан узел.jpg', 'Дизайн сан.узла ', 'upload/gallery/35/сан узел.jpg', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:04:35', '2015-12-11 06:33:43', '2015-12-11 07:04:35'),
(4, 35, '', '', '', 'upload/gallery/35/small/1 (2).jpg', 'Дизайн интерьера кухни.', 'upload/gallery/35/1 (2).jpg', 0, '', 0, 'kyhnya', 0, 0, '', '', NULL, '2015-12-11 07:01:47', '2015-12-22 12:01:24'),
(5, 35, '', '', '', 'upload/gallery/35/small/3.jpg', 'Дизайн санузла.', 'upload/gallery/35/3.jpg', 0, '', 0, 'sanyzel', 0, 0, '', '', NULL, '2015-12-11 07:04:17', '2016-01-11 05:21:26'),
(6, 35, '', '', '', 'upload/gallery/35/small/16.jpg', 'Дизайн интерьера  гостиной загородного дома.', 'upload/gallery/35/16.jpg', 0, '', 0, 'kaminvdome', 0, 0, '', '', NULL, '2015-12-11 07:05:08', '2015-12-22 12:00:59'),
(7, 36, '', '', '', 'upload/gallery/36/small/IMG_6884.JPG', 'Дизайн спальни для гостинцы "Екатерины"', 'upload/gallery/36/IMG_6884.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:38:01', '2015-12-11 07:06:37', '2015-12-11 07:38:01'),
(8, 36, '', '', '', 'upload/gallery/36/small/IMG_6929.JPG', 'Дизайн спальни', 'upload/gallery/36/IMG_6929.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:37:08', '2015-12-11 07:07:09', '2015-12-11 07:37:08'),
(9, 36, '', '', '', 'upload/gallery/36/small/IMG_6862.JPG', 'Дизайн спальни отеля «Екатерина».', 'upload/gallery/36/IMG_6862.JPG', 0, '', 0, 'spalinya', 0, 0, '', '', NULL, '2015-12-11 07:08:07', '2015-12-23 11:45:25'),
(10, 36, '', '', '', 'upload/gallery/36/small/IMG_6861.JPG', 'Дизайн спальни', 'upload/gallery/36/IMG_6861.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:37:19', '2015-12-11 07:08:22', '2015-12-11 07:37:19'),
(11, 36, '', '', '', 'upload/gallery/36/small/IMG_6996.JPG', 'Дизайн спальни. Отель «Екатерина».', 'upload/gallery/36/IMG_6996.JPG', 0, '', 0, 'spalnyaipufic', 0, 0, '', '', NULL, '2015-12-11 07:08:45', '2015-12-23 11:45:49'),
(12, 36, '', '', '', 'upload/gallery/36/small/IMG_6868.JPG', 'Дизайн гостиной .Отель «Екатерина».', 'upload/gallery/36/IMG_6868.JPG', 0, '', 0, 'gostinaya', 0, 0, '', '', NULL, '2015-12-11 07:09:08', '2015-12-23 11:45:13'),
(13, 36, '', '', '', 'upload/gallery/36/small/IMG_6930.JPG', 'Дизайн  ванной комнаты', 'upload/gallery/36/IMG_6930.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:45:05', '2015-12-11 07:09:28', '2015-12-11 07:45:05'),
(14, 36, '', '', '', 'upload/gallery/36/small/IMG_6901.JPG', 'Дизайн ванной комнаты', 'upload/gallery/36/IMG_6901.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:46:11', '2015-12-11 07:09:46', '2015-12-11 07:46:11'),
(15, 36, '', '', '', 'upload/gallery/36/small/IMG_6902.JPG', 'Дизайн ванной комнаты отеля «Екатерина».', 'upload/gallery/36/IMG_6902.JPG', 0, '', 0, 'rakovina', 0, 0, '', '', NULL, '2015-12-11 07:10:03', '2015-12-23 11:45:06'),
(16, 36, '', '', '', 'upload/gallery/36/small/IMG_1955.JPG', 'Дизайн гостиной квартиры.', 'upload/gallery/36/IMG_1955.JPG', 0, '', 0, 'holl', 0, 0, '', '', NULL, '2015-12-11 07:10:24', '2015-12-22 11:52:54'),
(17, 36, '', '', '', 'upload/gallery/36/small/IMG_7083.JPG', 'Дизайн ресторана «Штакеншнейдер»', 'upload/gallery/36/IMG_7083.JPG', 0, '', 0, 'restoran', 0, 0, '', '', NULL, '2015-12-11 07:10:50', '2015-12-22 11:53:03'),
(18, 36, '', '', '', 'upload/gallery/36/small/IMG_6899.JPG', 'Дизайн спальни отеля «Екатерина».', 'upload/gallery/36/IMG_6899.JPG', 0, '', 0, 'spalinyaotelya', 0, 0, '', '', NULL, '2015-12-11 07:13:05', '2015-12-23 11:44:53'),
(19, 36, '', '', '', 'upload/gallery/36/small/IMG_7051.JPG', 'Дизайн гостиной', 'upload/gallery/36/IMG_7051.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:46:59', '2015-12-11 07:13:57', '2015-12-11 07:46:59'),
(20, 36, '', '', '', 'upload/gallery/36/small/53713404.jpg', 'Лестничный пролёт.Отель «Екатерина».', 'upload/gallery/36/53713404.jpg', 0, '', 0, 'lestnisaikover', 0, 0, '', '', NULL, '2015-12-11 07:14:24', '2015-12-23 11:44:42'),
(21, 36, '', '', '', 'upload/gallery/36/small/IMG_6850.JPG', 'Дизайн гостиной ', 'upload/gallery/36/IMG_6850.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:14:50', '2015-12-11 07:14:39', '2015-12-11 07:14:50'),
(22, 36, '', '', '', 'upload/gallery/36/small/IMG_6850.JPG', 'Дизайн гостиной', 'upload/gallery/36/IMG_6850.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 07:16:04', '2015-12-11 07:15:23', '2015-12-11 07:16:04'),
(23, 36, '', '', '', 'upload/gallery/36/small/Depositphotos_34017815_m-2015.jpg', 'Интерьер гостиной в стиле Прованс.', 'upload/gallery/36/Depositphotos_34017815_m-2015.jpg', 0, '', 0, 'styleprovans', 0, 0, '', '', NULL, '2015-12-11 07:27:15', '2015-12-22 11:53:41'),
(24, 36, '', '', '', 'upload/gallery/36/small/35.1024x.jpg', 'Дизайн прихожей квартиры.', 'upload/gallery/36/35.1024x.jpg', 0, '', 0, 'prihozhaya', 0, 0, '', '', NULL, '2015-12-11 07:34:41', '2015-12-22 11:53:55'),
(25, 36, '', '', '', 'upload/gallery/36/small/36.1024x.jpg', 'Дизайн коридора квартиры.', 'upload/gallery/36/36.1024x.jpg', 0, '', 0, 'koridor', 0, 0, '', '', NULL, '2015-12-11 07:34:54', '2015-12-22 11:54:08'),
(26, 36, '', '', '', 'upload/gallery/36/small/ME9oQ69RBWY.jpg', 'Дизайн коридора.', 'upload/gallery/36/ME9oQ69RBWY.jpg', 0, '', 0, 'lestnisa', 0, 0, '', '', NULL, '2015-12-11 07:53:15', '2015-12-23 11:44:32'),
(27, 36, '', '', '', 'upload/gallery/36/small/PAvQT80SaZI.jpg', 'Дизайн двора.', 'upload/gallery/36/PAvQT80SaZI.jpg', 0, '', 0, 'dvorrestorana', 0, 0, '', '', NULL, '2015-12-11 07:53:20', '2015-12-23 11:44:25'),
(28, 36, '', '', '', 'upload/gallery/36/small/53521170.jpg', 'Дизайн камина. Отель «Екатерина».', 'upload/gallery/36/53521170.jpg', 0, '', 0, 'kamin', 0, 0, '', '', NULL, '2015-12-11 07:56:48', '2015-12-23 11:44:18'),
(29, 36, '', '', '', 'upload/gallery/36/small/53489657.jpg', 'Дизайн ресепшена. Отель «Екатерина».', 'upload/gallery/36/53489657.jpg', 0, '', 0, 'ressepshian', 0, 0, '', '', NULL, '2015-12-11 07:57:00', '2015-12-23 11:43:59'),
(30, 35, '', '', '', 'upload/gallery/35/small/headbg.jpg', '', 'upload/gallery/35/headbg.jpg', 0, '', 0, '', 0, 0, '', '', '2015-12-11 10:08:35', '2015-12-11 08:39:51', '2015-12-11 10:08:35'),
(31, 35, '', '', '', 'upload/gallery/35/small/house6.jpg', 'Макет  загородного дома', 'upload/gallery/35/house6.jpg', 0, '', 0, '', 0, 0, '', '', '2015-12-11 10:08:44', '2015-12-11 08:40:08', '2015-12-11 10:08:44'),
(32, 35, '', '', '', 'upload/gallery/35/small/angar5.jpg', 'Макет.', 'upload/gallery/35/angar5.jpg', 0, '', 0, 'maket', 0, 0, '', '', NULL, '2015-12-11 08:40:29', '2015-12-22 12:00:43'),
(33, 35, '', '', '', 'upload/gallery/35/small/дом3гот.jpg', 'Макет дома.', 'upload/gallery/35/дом3гот.jpg', 0, '', 0, 'makethome', 0, 0, '', '', NULL, '2015-12-11 10:09:02', '2015-12-22 12:00:33'),
(34, 35, '', '', '', 'upload/gallery/35/small/диван.jpg', 'Дизайн гостиной загородного дома.', 'upload/gallery/35/диван.jpg', 0, '', 0, 'sofa', 0, 0, '', '', NULL, '2015-12-11 10:09:17', '2015-12-23 09:28:50'),
(35, 36, '', '', '', 'upload/gallery/36/small/3302031906.jpg', 'Дизайн номера. Отель  «Екатерина».', 'upload/gallery/36/3302031906.jpg', 0, '', 0, 'spalyaniabiruzovya', 0, 0, '', '', NULL, '2015-12-11 10:09:40', '2015-12-23 11:43:40'),
(36, 36, '', '', '', 'upload/gallery/36/small/3942711206.jpg', 'Дизайн квартиры в классическом стиле.', 'upload/gallery/36/3942711206.jpg', 0, '', 0, 'spalnyastyle', 0, 0, '', '', NULL, '2015-12-11 10:09:53', '2015-12-22 11:56:46'),
(37, 36, '', '', '', 'upload/gallery/36/small/4750065806.jpg', 'Дизайн  спальни.', 'upload/gallery/36/4750065806.jpg', 0, '', 0, 'krovat\'', 0, 0, '', '', NULL, '2015-12-11 10:10:04', '2015-12-22 11:57:41'),
(38, 36, '', '', '', 'upload/gallery/36/small/otel_petr_sanktpeterburg_ed71c76b130cb25a66959f93b611ff84 - копия.JPG', '', 'upload/gallery/36/otel_petr_sanktpeterburg_ed71c76b130cb25a66959f93b611ff84 - копия.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 10:13:50', '2015-12-11 10:10:19', '2015-12-11 10:13:50'),
(39, 36, '', '', '', 'upload/gallery/36/small/otel_petr_sanktpeterburg_ed71c76b130cb25a66959f93b611ff84 - копия.JPG', '', 'upload/gallery/36/otel_petr_sanktpeterburg_ed71c76b130cb25a66959f93b611ff84 - копия.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 10:14:33', '2015-12-11 10:14:26', '2015-12-11 10:14:33'),
(40, 36, '', '', '', 'upload/gallery/36/small/otel_petr_sanktpeterburg_ed71c76b130cb25a66959f93b611ff84 - копия.JPG', '', 'upload/gallery/36/otel_petr_sanktpeterburg_ed71c76b130cb25a66959f93b611ff84 - копия.JPG', 0, '', 0, '', 0, 0, '', '', '2015-12-11 10:15:03', '2015-12-11 10:14:56', '2015-12-11 10:15:03'),
(41, 36, '', '', '', 'upload/gallery/36/small/1.JPG', 'Дизайн спальни.', 'upload/gallery/36/1.JPG', 0, '', 0, 'belyatumbochka', 0, 0, '', '', NULL, '2015-12-11 10:15:41', '2015-12-22 11:58:10'),
(42, 35, '', '', '', 'upload/gallery/35/small/receptionWindow.jpg', 'Дизайн гостиной.', 'upload/gallery/35/receptionWindow.jpg', 0, '', 0, 'gostinayadoma', 0, 0, '', '', NULL, '2015-12-23 09:27:53', '2015-12-23 09:27:53'),
(43, 36, '', '', '', 'upload/gallery/36/small/IMG_8999.jpg', 'Дизайн  ресепшена отеля «1913»', 'upload/gallery/36/IMG_8999.jpg', 0, '', 0, ' reception', 0, 0, '', '', NULL, '2015-12-23 11:40:54', '2015-12-23 11:43:22'),
(44, 36, '', '', '', 'upload/gallery/36/small/IMG_8995.jpg', 'Дизайн  ресепшена отеля «1913»', 'upload/gallery/36/IMG_8995.jpg', 0, '', 0, ' reception', 0, 0, '', '', NULL, '2015-12-23 11:48:41', '2015-12-23 11:48:41'),
(45, 35, '', '', '', 'upload/gallery/35/small/М10чердакОФ1гот.jpg', 'дизайн офиса.\r\nстиль лофт.', 'upload/gallery/35/М10чердакОФ1гот.jpg', 0, '', 0, 'office loft', 0, 0, '', '', NULL, '2016-01-20 06:26:26', '2016-01-20 06:26:26'),
(46, 35, '', '', '', 'upload/gallery/35/small/М10чердакОФ5гот.jpg', 'зона релакса в офисе.', 'upload/gallery/35/М10чердакОФ5гот.jpg', 0, '', 0, 'office loft', 0, 0, '', '', NULL, '2016-01-20 06:28:14', '2016-01-20 06:28:14'),
(47, 35, '', '', '', 'upload/gallery/35/small/М10чердакОФ3гот.jpg', 'Рабочие места в офисе на мансарде.', 'upload/gallery/35/М10чердакОФ3гот.jpg', 0, '', 0, 'office loft ', 0, 0, '', '', NULL, '2016-01-20 06:29:48', '2016-01-20 06:29:48');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_05_27_090737_create_users_table', 1),
('2015_05_27_105748_create_posts_table', 1),
('2015_06_01_111330_create_types_table', 1),
('2015_06_24_094646_create-rates-table', 1),
('2015_07_02_130216_create_settings_table', 1),
('2015_07_02_141648_create_sliders_table', 1),
('2015_07_08_120036_create_password_reminders_table', 1),
('2015_07_09_123836_create_gallerys_table', 1),
('2015_07_15_133739_create_requests_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_reminders`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `password_reminders`;
CREATE TABLE `password_reminders` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` smallint(6) NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `preview` text COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent` smallint(6) NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `order` smallint(6) NOT NULL,
  `noindex` tinyint(1) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `type_id`, `slug`, `name`, `title`, `preview`, `text`, `image`, `parent`, `tags`, `status`, `order`, `noindex`, `description`, `keywords`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 3, 'afrikanskiy', 'Африканский', 'Африканский стиль в интерьере| Африканский  дизайн | Квартира в Африканском стиле ', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Африканский стиль вытекает из двух стилей: марокканского и египетского, что, в свою очередь, придаёт некоторую экстравагантность интерьеру. Благодаря множеству плетёной мебели и изделий из дерева, украшенных резьбой, чувствуется дух местной природы, ее фактуры и цвета. С одной стороны интерьер динамичный, а с другой &ndash;&nbsp; по-своему минималистичен&nbsp;и диковат.&nbsp;<o:p></o:p></span></p>\r\n', 'Depositphotos_5255036_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, стиль, африканский,дешево, заказать, Санкт-Петербург.', NULL, '2015-11-24 19:14:44', '2016-01-11 10:27:03'),
(2, 3, 'vostochnyiy', 'Восточный', ' Восточный стиль |Восточный стиль в гостиной |Восточный стиль в интерьере кухни', '', '<p><span style="font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">Восток-дело тонкое! Не зря в восточном стиле особое внимание уделяется деталям&nbsp;.&nbsp;</span><span style="font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">Дома, оформленные в восточном стиле, отличаются неповторимой простотой и роскошью.&nbsp;</span><span style="font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">Здесь невольно начинаешь ощущать себя героем арабских сказок. Главными особенностями восточного стиля в интерьере являются мягкая приземистая мебель, яркая текстильная драпировка стен, пестрые орнаменты, аксессуары и ковры ручной работы.</span></p>\r\n', 'Depositphotos_4688895_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера,стиль, восточный дешево, заказать, Санкт-Петербург.', NULL, '2015-11-24 19:15:10', '2016-01-11 10:27:03'),
(3, 3, 'egipetskiy', 'Египетский', 'Египетский стиль | Дизайн спальни в Египетском стиле| Квартира в Египетском стиле', '', '<p><span style="font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">Одно из главных особенностей египетского стиля &mdash; это наличие узоров, орнаментов и разнообразных оттенков жёлтого. Интерьер, выдержанный в египетском стиле, всегда выглядит роскошным. </span>&nbsp;<span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Большое количество золота и скульптур с изображением священных египетских кошек.<o:p></o:p></span>&nbsp;<span style="font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">При создании такого интерьера важно соблюсти цветовой баланс!</span></p>\r\n', 'Depositphotos_3786200_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, египетский,заказать, Санкт-Петербург.', NULL, '2015-11-24 19:15:37', '2016-01-11 10:27:03'),
(4, 3, 'indiyskiy', 'Индийский', 'Индийский стиль | дизайн интерьера в индийском стиле| Гостиная в индийском стиле ', '', '<p><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Пестрая расцветка, скромная мебель с элементами ажура, наличие композиций с изображением животных. Множество шкатулок и шёлка. Всё это придаёт необходимую индийскую экзотику, шарм и привкус изящества.<o:p></o:p></span></p>\r\n', 'indijskij-stil-v-interere1.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, заказать, стиль ,индийский,Санкт-Петербург.', NULL, '2015-11-24 19:15:59', '2016-01-11 10:27:03'),
(5, 1, 'price', 'Стоимость', 'Стоимость', '', '<div class="col-sm-12">\r\n<h2>Стоимость</h2>\r\n\r\n<hr />\r\n<table class="table table-striped">\r\n	<tbody>\r\n		<tr>\r\n			<th>&nbsp;</th>\r\n			<th>Эскизный</th>\r\n			<th>Стандарт</th>\r\n			<th>Максимум</th>\r\n			<th>Максимум+</th>\r\n		</tr>\r\n		<tr>\r\n			<td>Обмерный план</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Составление технического задания</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>План расстановки мебели в 7-8 вариантах</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>3D визуализации всех помещений в 2-3 стилях</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Полный комплект рабочей документации для строителей</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Составление бюджета на проект</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Подбор финишных отделочных материалов,сантехники, мебели</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Интенграция инженерного оборудования в дизайн-проект</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Развертка стен</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Декорирования интерьера</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Работа с заказными изделиями,заказ, надзор за исполнением</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Выезд дизайнера вместе с Вами в салоны поставщиков</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Авторский надзор</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<th>Стоимость</th>\r\n			<th>от 600 р/м.кв</th>\r\n			<th>от 1000 р/м.кв</th>\r\n			<th>от 1500 р/м.кв</th>\r\n			<th>от 3000 р/м.кв</th>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n', '', 0, '', 1, 0, 0, '', '', '2015-12-11 05:36:53', '2015-11-25 17:12:40', '2015-12-11 05:36:53'),
(6, 3, 'kitayskiy', 'Китайский', 'Китайский стиль | Интерьер кухни в китайском стиле', '', '<p><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Китайский стиль отличается своей утонченностью.&nbsp;Палитра красок в интерьере навевает спокойствие и безмятежность. Одна из главных особенностей стиля &mdash; это слаженность и лёгкая строгость, без загруженности аксессуарами и различной мебельной атрибутикой.<o:p></o:p></span></p>\r\n', 'Chinese-living-dining-room-decoration-3D-design-Wallpaper-HD-1024x678.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, китайский, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:03:36', '2016-01-11 10:27:04'),
(7, 3, 'marokkanskiy', 'Марокканский', 'Марокканский стиль | Марокканский стиль в интерьере дома', '', '<p dir="ltr"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Марокканский стиль &mdash; это роскошь африканского стиля. В интерьере имеется множество исключительных атрибутов, позволяющих раскрыть всю палитру пылающей Африки. Этот стиль вместил в себя испанские, арабские и даже греческие нотки.<o:p></o:p></span></p>\r\n', 'Depositphotos_9919384_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, марокканский,заказать, Санкт-Петербург.', NULL, '2015-12-07 08:04:15', '2016-01-11 10:27:04'),
(8, 3, 'meksikanskiy', 'Мексиканский', 'Интерьер в мексиканском стиле| Интерьер квартиры в Мексиканском стиле | Мексиканский стиль', '', '<p dir="ltr">В мексиканском стиле сразу чувствуется национальный контраст. Солнечный и яркий интерьер раскрывает уникальность мексиканской культуры. Жгучая смесь европейских колонизаторов и индейцев вместила&nbsp;в себя всю культуру нации Западного полушария. Особую экстравагантность стилю придаёт наличие в интерьере статуй католических святых.</p>\r\n\r\n<div>&nbsp;</div>\r\n', 'Depositphotos_48090137_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, мексиканский,заказать, Санкт-Петербург.', NULL, '2015-12-07 08:04:45', '2016-01-11 10:27:04'),
(9, 3, 'provans', 'Прованс', 'Прованс стиль | Интерьер дома в  стиле Прованс', '', '<p dir="ltr">&nbsp;</p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Стиль Прованс &mdash; это, своего рода, деревенский шик в интерьере дома.&nbsp;Прованс &mdash; сочетание различных стилей всех областей,&nbsp;расположенных на юге Франции.&nbsp; Лаконичная обстановка, присутствие удобной мебели,&nbsp; использование&nbsp; инновационных технологий в отделке помещений,&nbsp; светлые пастельные тона.<o:p></o:p></p>\r\n\r\n<p>&nbsp;</p>\r\n', 'Depositphotos_48411383_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, заказать, стиль, прованс,Санкт-Петербург.', NULL, '2015-12-07 08:05:12', '2016-01-11 10:27:04'),
(10, 3, 'skandinavskiy', 'Скандинавский', 'Скандинавский', '', '<p dir="ltr"><span style="color:rgb(0, 0, 0); font-family:arial; font-size:13.3333px">Скандинавский стиль в интерьере &ndash; это функциональные деревянные конструкции, оформления стен и потолка, сочетающий в себе простоту и контрастность.</span></p>\r\n\r\n<p dir="ltr"><span style="color:rgb(0, 0, 0); font-family:arial; font-size:13.3333px">Интерьер, в скандинавском стиле, должен выглядеть в неизменном лёгком и умеренном стиле, особенно, если это гостиная или спальня.</span></p>\r\n\r\n<div>&nbsp;</div>\r\n', '', 0, '', 1, 0, 0, '', '', '2015-12-07 08:06:26', '2015-12-07 08:05:39', '2015-12-07 08:06:26'),
(11, 3, 'skandinavskiy', 'Скандинавский', 'Скандинавский стиль |Кухня в Скандинавском стиле |Скандинавский дизайн', '', '<p>Скандинавский стиль в интерьере сочетает в себе простоту и контрастность. Преимущественно используются природные материалы: древесина, металл, хлопок, натуральные камни, кожа и мех. Интерьер в скандинавском стиле должен выглядеть легко и умеренно, особенно если это гостиная или спальня.<o:p></o:p></p>\r\n\r\n<div>&nbsp;</div>\r\n', 'Depositphotos_52566447_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, скандинавский,заказать, Санкт-Петербург.', NULL, '2015-12-07 08:06:13', '2016-01-11 10:27:04'),
(12, 3, 'avangard', 'Авангард', 'Стиль Авангард в интерьере| дизайн гостиной в стиле Авангард  ', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Основной отличительной чертой авангарда является сочетание несочетаемого. Яркий контраст,&nbsp;бросающийся в глаза &mdash; основа авангарда. Иногда такой стиль называют гармонией контрастов, так как в авангарде возможен&nbsp;микс&nbsp;красок. Трудно найти свой стиль интерьера, когда есть колоссальное число&nbsp;разнообразных стилей со своими уникальными особенностями и цветовой палитрой. Но если есть желание сделать свою квартиру максимально оригинальной, то авангардный стиль придётся вам по вкусу.<o:p></o:p></span></p>\r\n', 'Depositphotos_83410422_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, авангард, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:07:02', '2016-01-11 10:27:04'),
(13, 3, 'ampir', 'Ампир', 'Ампир стиль | интерьер гостиных в стиле Ампир| Дизайн квартиры в стиле Ампир', '', '<p dir="ltr"><span style="font-size: 12pt; font-family: \'Times New Roman\', serif;">Чтобы придать солидности интерьеру используя стиль ампир, &nbsp;необходимы большие площади. Минимализм тут неуместен. Хорошо подобранный дизайн обратит простую квартиру в королевские апартаменты. Для стиля ампир характерны шкафы с ажурной резьбой и массивные кресла с&nbsp; позолотой. В помещении в стиле ампир ярко выражены насыщенные тона в отделке мебели, стен и пола. Погрузившись в этот стиль, &nbsp;ощущаешь роскошь, изысканность и нотки пафоса. Почувствуйте себя аристократом, создав неповторимый дизайн интерьера в стиле ампир.</span><o:p></o:p></p>\r\n\r\n<div>&nbsp;</div>\r\n', 'Depositphotos_45737021_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, ампир,заказать, Санкт-Петербург.', NULL, '2015-12-07 08:07:21', '2016-01-11 10:27:04'),
(14, 3, 'antichnyiy', 'Античный', 'Античный стиль в интерьере| Античный дизайн интерьера', '', '<p>&nbsp;Античный стиль помогает погрузиться в историю древнего Рима и Греции. Это стиль изящества и гармонии. Важной колоритной деталью в античном стиле является преобладание натуральных оттенков. Главной особенностью является присутствие архитектурных элементов. Античный стиль сочетает в себе простую деловитость Греции и возвышенность Рима, выдержать такой баланс по силам лишь опытному дизайнеру.</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'Depositphotos_3642751_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, античный,заказать, Санкт-Петербург.', NULL, '2015-12-07 08:07:46', '2016-01-11 10:27:04'),
(15, 3, 'barokko-', 'Барокко', 'Дизайн в стиле Барокко| Интерьер квартиры в стиле Барокко | Стиль Барокко', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Стиль барокко в интерьере зародился в XVII &mdash; XVIII веках. В нём широко используется золото, мрамор и различные породы дерева, что позволяет чётко выразить всю величественность интерьера. Барокко &ndash;&nbsp; один из немногих стилей,&nbsp; дошедших до наших дней, который не подвергся значительным изменениям и не потерял свою популярность. Находясь в интерьере в стиле, барокко вы можете почувствовать себя частью высшего общества.<o:p></o:p></span></p>\r\n', 'Depositphotos_57117303_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, барокко, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:19:30', '2016-01-11 10:27:04'),
(16, 3, 'gotika', 'Готика', 'Готика стиль в интерьере| дизайн дома готика| квартира в стиле Готика| ', '', '<p dir="ltr" style="text-align:justify"><span style="font-size: 12pt; font-family: \'Times New Roman\', serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Готика &ndash; это огромные окна, многоцветные мозаичные витражи, множество камней и стекла. Заглянув&nbsp;в помещение</span><span lang="EN-US" style="font-size: 12pt; font-family: \'Times New Roman\', serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">,</span><span style="font-size: 12pt; font-family: \'Times New Roman\', serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"> сразу чувствуется дух Средневековья. Интерьеры с дизайном в готическом стиле отличаются величием и изяществом. Одна из главных особенностей готики это заострённость форм. Так же активно используются натуральные материалы:&nbsp; дерево, камень, мрамор, металл. &nbsp;Реализовать в современных жилищах готический стиль - задача не из лёгких, но некоторые элементы довольно часто применяются для декорирования загородных домов</span></p>\r\n\r\n<div>&nbsp;</div>\r\n', 'hd_aafbb71f-c90f-4135-a134-19f9e436f18e.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, заказать, стиль, готика,Санкт-Петербург.', NULL, '2015-12-07 08:19:55', '2016-01-11 10:27:04'),
(17, 3, 'kantri', 'Кантри', 'Кантри стиль в интерьере| дизайн кантри| квартира в стиле Кантри| ', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Основной особенностью стиля кантри является обращение к деревенским мотивам. Интерьер в стиле кантри отражает простоту деревенского уклада и его близость к природе. Сейчас стиль кантри отличается от стиля,&nbsp;зародившегося в прошлом веке. Главной изюминкой кантри является естественность и простота без какой-либо вычурности, цветовая особенность кантри &mdash; &nbsp;неяркие естественные оттенки. На нынешний день интерьер в стиле кантри используется в оформлении дач и загородных домов.<o:p></o:p></span></p>\r\n', 'Depositphotos_2393361_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, кантри, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:20:14', '2016-01-11 10:27:04'),
(18, 3, 'kitch', 'Китч', 'Китч стиль интерьера| Интерьер квартиры в  стиле китч ', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="color: black; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Китч, наверное, самый яркий и необычный стиль. Особенность дизайна в стиле китч состоит в том, чтобы отойти от всех стандартов и сразить наповал неожиданными сочетаниями и элементами. Всё самое блестящее, кричащее, навязчивое и нарочито вульгарное &ndash; это китч! Цветовая гамма интерьера - преимущественно ядовитые цвета с элементами пастельных тонов.<o:p></o:p></span></p>\r\n', 'd295f92ecf779440172f30732698.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, китч, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:20:36', '2016-01-11 10:27:04'),
(19, 3, 'klassitsizm', 'Классицизм', 'Классицизм стиль в интерьере| дизайн квартиры в стиле классицизм', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Стиль классицизм пронизан духом европейской культуры. Характерная цветовая гамма классицизма &mdash; это спокойные и благородные тона, тёплая, светлая, пастельная палитра. Контрасты сведены к минимуму. В интерьере нет захламлённости, пространство не перегружено деталями. В классическом интерьере много зеркал, которые зрительно расширяют помещение. Колонны с бронзовыми капителями очень органично дополняют классический интерьер. Так же, для стиля классицизм</span><span lang="EN-US" style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">,</span><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"> характерно присутствие лепнины. Отделка стен осуществляется однотонной декоративной штукатуркой, помимо этого стены дополнительно украшаются оригинальными картинами и стильными принтами.<o:p></o:p></span></p>\r\n', 'Depositphotos_4739528_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, классицизм, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:21:12', '2016-01-11 10:27:04'),
(20, 3, 'konstruktivizm-', 'Конструктивизм', 'Конструктивизм интерьерер| Конструктивизм в интерьере квартиры', '', '<p dir="ltr" style="text-align:justify"><span style="color: black; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Главная особенность конструктивизма как стиля &ndash; это намеренное акцентирование внимания на конструкции, а не на композиции. Конструктивизм заставил по-новому взглянуть на создание интерьера - эстетика геометрических композиций стала формирующей чертой. Лаконичность и функциональность - &nbsp;девиз конструктивизма. Отделка стен осуществляется однотонной декоративной штукатуркой, используются украшения в виде уникальных картин и элегантных принтов.<o:p></o:p></span></p>\r\n\r\n<div>&nbsp;</div>\r\n', 'Depositphotos_13746580_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, конструктивизм, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:21:38', '2016-01-11 10:27:04'),
(21, 3, 'loft', 'Лофт', 'Лофт стиль в интерьере| дизайн в стиле лофт', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Лофт &ndash; это сочетание старой кирпичной стены с ультрасовременной бытовой техникой. Необычный стиль интерьера лофт может прижиться не только в городской квартире, но и в компактном загородном доме. Это стиль, в котором отлично сочетаются яркие колоритные краски, присутствуют нотки бунтарства и атмосфера демократичности. Стиль лофт способен превратить нежилое помещение в престижное, современное и комфортное жилье.</span><span style="color: black; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><o:p></o:p></span></p>\r\n', 'Depositphotos_44591399_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, лофт,заказать, Санкт-Петербург.', NULL, '2015-12-07 08:21:58', '2016-01-11 10:27:04'),
(22, 3, 'minimalizm-', 'Минимализм', 'Минимализм в интерьере| дизайн квартиры в стиле минимализм|  ', '', '<p dir="ltr" style="text-align:justify"><span style="font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">Минимализм&nbsp;&mdash; это посредственный стиль. Главная особенность минимализма &mdash; это минимум предметов и максимум свободного пространства. Декор сведён к минимуму или вовсе отсутствует. Если в традиционном стиле массивность и добротность материала имеют основное значение, то в стиле минимализм ценность отдаётся функциональности. Этот лаконичный стиль интерьера имеет собственную философию и политику. Это стиль жизни, а не просто дань моде. Этот стиль отлично подходит для офисов и общественных заведений.</span></p>\r\n\r\n<div>&nbsp;</div>\r\n', 'Depositphotos_43139571_original.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, минимализм, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:22:20', '2016-01-11 10:48:46'),
(23, 3, 'renessans', 'Ренессанс', 'Ренессанс в интерьере дома| дизайн квартиры| ренессанс стиль', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Стиль Ренессанс зародился в эпоху Возрождения. Благодаря роскошному внутреннему убранству, чувствуется королевский шик. В интерьере присутствуют мраморные лестницы, античные скульптуры и обилие лепнины. Гостиные и спальни оборудованы дорогой мебелью, исполненной в духе античности. Цветовая гамма ренессанса мягкая, без ярких акцентов. Всё спокойно и гармонично.<o:p></o:p></span></p>\r\n\r\n<div>&nbsp;</div>\r\n', 'Depositphotos_62715983_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, ренессанс, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:22:56', '2016-01-11 10:46:06'),
(24, 3, 'rokoko', 'Рококо', 'Рококо в дизайне интерьера| квартира в стиле рококо', '', '<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Стиль рококо &ndash; зародился в начале восемнадцатого века. Рококо - это карнавальный стиль, в котором используются ассиметричные, динамичные, сложные изогнутые формы. В колорите стиля доминируют нежные пастельные тона. Рококо в интерьере известен богатством цвета и роскошью. Несмотря на большую декоративную нагрузку интерьера, помещение в стиле рококо всегда будет выглядеть элегантно.<o:p></o:p></span></p>\r\n', 'Depositphotos_1359091_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, рококо, заказать, Санкт-Петербург.', NULL, '2015-12-07 08:34:53', '2016-01-11 10:46:06'),
(25, 3, 'romanskiy', 'Романский', 'Романский стиль| квартира в романском стиле', '', '<p dir="ltr" style="text-align:justify"><span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Атмосфера покоя и стабильности царит в апартаментах, выполненных в романском стиле. Массивность, строгость, отсутствие излишеств, величественно спокойный декор - все это характеризует романский стиль. Простая мебель с разнообразной росписью, стены с имитацией под камень, колонны, камины, широкие лестницы, полуциркульные&nbsp; арки &ndash; это необходимые элементы, которые присущи романскому стилю.<o:p></o:p></span></p>\r\n', 'Depositphotos_59827175_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, романский, заказать, Санкт-Петербург.', NULL, '2015-12-07 09:36:06', '2016-01-11 10:46:06'),
(26, 3, 'hay-tek', 'Хай-тек', 'Хай-тек интерьер| квартира в стиле hi-tech', '', '<p style="margin: 0cm 0cm 7.5pt; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Среди всех популярных на сегодняшний день стилей, хай-тек занимает одно из&nbsp; первых мест! Хай-тек можно охарактеризовать как динамичный, функциональный, комфортабельный, следующий модным тенденциям стиль. Основные цвета &ndash; белый, чёрный и серый. Стиль запоминается частым использованием металла, стекла и пластика в интерьере и архитектуре.<o:p></o:p></p>\r\n', 'Depositphotos_11622101_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево,стиль, hi tech, заказать, Санкт-Петербург.', NULL, '2015-12-07 09:40:25', '2016-01-11 10:46:07'),
(27, 3, 'elektika', 'Эклектика', 'Эклектика в интерьере квартиры| эклектика дизайн интерьера', '', '<p style="margin: 0cm 0cm 7.5pt; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Э<span style="background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">клектика является одним из наиболее популярных стилей в дизайне интерьера.&nbsp; Для эклектики свойственны смелые дизайнерские решения в планировке и декоре, контраст цветов и материалов. Эклектика совмещает в себе разнообразные стили, такие как поп-арт, минимализм, хай-тек и даже конструктивизм. Чаще всего эклектика используется для соединения более элегантных стилей, таких как барокко и ампир.<o:p></o:p></span></p>\r\n', 'hd_7771392b-317c-4eee-b9d9-1bea327886c8.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от профессионалов. Скидки и акции.Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, эклектика,заказать, Санкт-Петербург.', NULL, '2015-12-07 09:40:50', '2016-01-11 10:46:07'),
(28, 3, 'yaponskiy', 'Японский', 'Японский стиль в интерьере| квартира в  японском стиле|  Интерьер в японском стиле', '', '<p style="margin: 0cm 0cm 7.5pt; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Главной особенностью японского стиля в интерьере являются чёткие цветовые сочетания и лаконичные формы. В интерьере все аккуратно и спокойно. Чувство меры особенно важно, иначе гостиная превратится в магазин японских товаров. В японском стиле особое внимание уделяется спокойным светлым тонам. Можно ограничиться стилизацией, объединив особенности интерьера Страны восходящего солнца с привычными удобствами. Или же &ldquo;японизировать&rdquo; интерьер в полной мере, устроив места для сна и приёма пищи на полу.<o:p></o:p></p>\r\n', 'Depositphotos_45126981_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от  профессионалов. Скидки и акции.Ремонт и отделка от профессионалов.', 'Дизайн, интерьера, дешево,стиль, японский,заказать, Санкт-Петербург.', NULL, '2015-12-07 09:41:12', '2016-01-11 10:46:07'),
(29, 3, 'ar-deko-', 'Ар деко', 'Ар деко стиль в интерьере| дизайн квартиры ар деко|  Дизайн спальни', '', '<p style="margin: 0cm 0cm 7.5pt; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><span style="color:black">Стиль ар-деко ориентирован на истинных любителей роскоши и изысканного стиля. Ар-деко тесно пересекается с такими стилями, как модерн и ампир. Основной отличительной чертой ар-деко является резкость и угловатость форм.&nbsp; Предпочтение отдаётся нейтральным тонам. В интерьере в стиле ар-деко присутствуют экзотические предметы, широко используются алюминий, сталь, латунь, ценные породы дерева, различные варианты инкрустаций и эмалей.<o:p></o:p></span></p>\r\n', 'Depositphotos_87650268_m-2015.jpg', 0, '', 1, 0, 0, 'Индивидуальный дизайн интерьера квартир, дома, комнаты, кухни в Санкт-Петербурге.Современные идеи дизайна дома от  профессионалов. Скидки и акции. Ремонт и отделка от профессионалов', 'Дизайн, интерьера, дешево, стиль, ар деко, заказать, Санкт-Петербург', NULL, '2015-12-07 09:42:07', '2016-01-11 10:46:07'),
(30, 3, 'ar-nuvo', 'Ар-нуво', 'Ар-нуво стиль в интерьере| дизайн ар-нуво| квартира в стиле ар-нуво', '', '<p dir="ltr">Стиль ар-нуво сочетает в себе естественные орнаменты и восточные мотивы. Зелёные &nbsp;тона и &nbsp;оттенки голубого&nbsp;являются основной цветовой гаммой в стиле ар-нуво. Извилистые линии, причудливые и изогнутые формы, окна и двери, украшенные арками с растительным&nbsp;орнаментом, &nbsp;мягкость линий и необыкновенная плавность очертаний&nbsp;подчёркивают элегантность интерьера, выполненного&nbsp;в стиле ар-нуво.</p>\r\n', 'Depositphotos_25527461_m-2015.jpg', 0, '', 1, 0, 0, 'Дизайн интерьера дома и квартир. Дизайн дома по лучшим ценам в Санкт-Петербурге.Скидки и акции.', 'Дизайн, интерьера, дешево,стиль, ар-нуво, заказать, Санкт-Петербург.', NULL, '2015-12-07 09:42:31', '2016-01-11 10:46:07'),
(31, 2, 'kontseptsiya-i-proektirovanie', 'Концепция / Проектирование', 'Концепция дизайна квартиры| проектирование домов в спб', '', '<div class="wrapped">\r\n<h1 class="im_msg_text" style="text-align: center;">Концепция / Проектирование</h1>\r\n\r\n<div class="im_msg_text" style="text-align: center;"><img alt="" src="/upload/image/photofacefun_com_1450862494.jpg" style="width: 949px; height: 703px;" /></div>\r\n\r\n<div class="im_msg_text"><br />\r\nДизайн &mdash; концепция самый важный шаг на пути к вашему дизайну мечты.<br />\r\nВ концепцию входят <strong>эскизы</strong> и <strong>трёхмерное изображение</strong>. Благодаря концепции структурируется общее понятие о том, каким будет реализованный проект.<br />\r\nС помощью дизайн&nbsp;&mdash; концепции вы сможете увидеть проект в целом. Иначе говоря, концепция дизайна &mdash; это идея вашего будущего дизайн-продукта.&nbsp;Представление о том, как он будет выглядеть в целом, от расположения текста, до графики.</div>\r\n\r\n<div class="im_msg_text">\r\n<p>&nbsp;</p>\r\n</div>\r\n\r\n<div class="im_msg_text">&nbsp;</div>\r\n\r\n<div class="im_msg_text">&nbsp;</div>\r\n</div>\r\n', '', 0, '', 1, 0, 0, '', '', NULL, '2015-12-09 07:41:35', '2015-12-23 06:41:48'),
(32, 2, '3d-modelirovanie-vizualizatsiya', '3D моделирование / Визуализация', '3D моделирование домов спб| Визуализация квартир спб', '', '<h1 style="text-align: center;">3D моделирование / Визуализация</h1>\r\n\r\n<p style="text-align: center;"><img alt="" src="/upload/image/depositphotos_9111619_m_2015_(1).jpg" style="width: 1000px; height: 750px;" /></p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><strong>У вас в голове зародилась мысль о том, каким должен быть ваш интерьер, но вы не представляете, как всё это будет выглядеть?</strong><o:p></o:p></p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><strong>Мы поможем</strong> воплотить ваши идеи в жизнь!<o:p></o:p></p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Благодаря визуальным наброскам вы сможете увидеть не только общую концепцию, но и рассмотреть интерьер дома в деталях.<o:p></o:p></p>\r\n', '', 0, '', 1, 0, 0, '', '', NULL, '2015-12-09 07:46:53', '2015-12-23 06:41:11'),
(33, 2, 'soprovojdenie-dekorirovanie', 'Сопровождение / Декорирование', 'Сопровождение проектов спб|  Декорирование помещений спб', '', '<h1 style="text-align: center;">Сопровождение / Декорирование</h1>\r\n\r\n<p style="text-align: center;"><img alt="" src="/upload/image/photofacefun_com_1450863308.jpg" style="width: 924px; height: 541px;" /></p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">&nbsp;<strong>Хотите красивый дизайн квартиры, но при этом нет желания тратить огромное количество средств?</strong><o:p></o:p></p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Сопровождение, а иными словами,<span class="apple-converted-space"><b>&nbsp;</b></span><strong>авторский надзор, </strong><span class="apple-converted-space">&nbsp;</span>подразумевает контроль дизайнера за строительством, закупкой материалов и мебели. Это способствует хорошей экономии.<o:p></o:p></p>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Во время авторского надзора ведётся журнал, в который вносятся все замечания и пожелания дизайнера.<o:p></o:p></p>\r\n', '', 0, '', 1, 0, 0, '', '', NULL, '2015-12-09 07:47:06', '2015-12-23 06:42:26'),
(34, 1, 'nashi-rabotyi', 'Наши работы', 'Наши работы', '', '', '', 0, '', 1, 0, 0, '', '', '2015-12-11 05:36:47', '2015-12-11 05:34:43', '2015-12-11 05:36:47'),
(35, 6, '3d-vizualizatsiya', '3D визуализация', '3D визуализация| 3d дизайн интерьера| работы Asafov Design', '', '<h2>3D визуализация</h2>\r\n', '', 0, '', 1, 2, 0, '', 'Визуализация, наши работы, портфолио.', NULL, '2015-12-11 05:38:07', '2015-12-22 12:03:07'),
(36, 6, 'gotovyie-rabotyi', 'Готовые работы', 'Портфолио Asafov Design| Работы Asafov Design ', '', '<h2>Готовые работы</h2>\r\n', '', 0, '', 1, 1, 0, '', 'портфолио, наши работы, фото.', NULL, '2015-12-11 06:53:03', '2015-12-22 12:03:22'),
(37, 4, 'dizayn-dlya-otelya-ekaterina', 'Дизайн  для отеля Екатерина', 'Дизайн  для отеля Екатерина', '', '<h2 style="font-style:italic;">Успешное завершение проекта!</h2>\r\n\r\n<hr />\r\n<p>Мы недавно закончили дизайн интерьера для отеля &quot;Екатерина&quot;.</p>\r\n\r\n<hr />\r\n<p><span style="color:#000000;"><var><small><big><img alt="" src="/upload/image/img_7083.jpg" style="width: 300px; height: 200px; float: left; margin: 10px;" /><img alt="" src="/upload/image/me9oq69rbwy.jpg" style="width: 199px; height: 300px; float: left; margin: 10px;" /><img alt="" src="/upload/image/pavqt80sazi.jpg" style="width: 450px; height: 300px; float: left; margin: 10px;" /></big></small></var></span></p>\r\n\r\n<p>Фотографии готовых работ</p>\r\n', 'upload/image/pavqtsazi.jpg', 0, '', 1, 0, 0, '', '', '2015-12-16 10:09:53', '2015-12-15 11:30:56', '2015-12-16 10:09:53'),
(38, 4, 'novosti-dizayn-otel-', 'Дизайн интерьера для Отеля "Екатерина"', 'новости | дизайн| отель|', '', '<h2 style="font-style: italic;">Успешное завершение проекта!</h2>\r\n\r\n<hr style="line-height: 20.8px;" />\r\n<p style="line-height: 20.8px;">Мы недавно закончили дизайн интерьера для отеля &quot;Екатерина&quot;.</p>\r\n\r\n<p style="line-height: 20.8px;"><img alt="" src="/upload/image/me9oq69rbwy_(1).jpg" style="width: 400px; height: 604px;" /><img alt="" src="/upload/image/img_6862.jpg" /></p>\r\n\r\n<p dir="rtl" style="line-height: 20.8px;">&nbsp;</p>\r\n\r\n<p dir="rtl" style="line-height: 20.8px;">&nbsp;</p>\r\n\r\n<p dir="rtl" style="line-height: 20.8px;">&nbsp;</p>\r\n', '', 0, '', 1, 0, 0, '', '', '2015-12-16 10:15:44', '2015-12-16 10:13:48', '2015-12-16 10:15:44'),
(39, 4, 'novosti-dizayn-otel-', 'Дизайн интерьера для отеля «Екатерина».', 'новости | дизайн| отель|', '', '<h2 style="font-style: italic;">Успешное завершение проекта!</h2>\r\n\r\n<hr style="line-height: 20.8px;" />\r\n<p style="line-height: 20.8px;">Закончили дизайн интерьера в классическом стиле для отеля &quot;Екатерина&quot;.</p>\r\n\r\n<p style="line-height: 20.8px;"><img alt="" src="/upload/image/img_6862_(1).jpg" /><img alt="" src="/upload/image/me9oq69rbwy_(2).jpg" style="width: 400px; height: 604px;" /><img alt="" src="/upload/image/r_1237116_ekg0cq7kt5mly933335o_1.jpg" style="width: 840px; height: 460px;" /></p>\r\n\r\n<p style="line-height: 20.8px;">&nbsp;</p>\r\n', 'pavqtsazi.jpg', 0, '', 1, 0, 0, '', '', NULL, '2015-12-16 10:16:33', '2016-01-11 10:46:07'),
(40, 4, 'novosti-dizayn-otel-dekorirovaniya', 'Дизайн интерьера для  отеля «1913».', 'новости | дизайн| отель', '', '<h1 style="text-align: center;"><strong><span style="font-family: ProximaNova, \'Open Sans\', Helvetica, sans-serif; font-size: 16px; line-height: 20.8px;">Завершили дизайн-проект.</span></strong></h1>\r\n\r\n<hr />\r\n<p style="text-align: center;"><span style="font-family:arial,helvetica,sans-serif;"><span style="font-size:16px;">&nbsp;Проект заключался в сопровождение и &nbsp;декорирование&nbsp;&nbsp;интерьера &nbsp;отеля. &nbsp;</span><span id="docs-internal-guid-6156aeb1-cfb7-0860-bf1d-3c9fb8bae684"><span style="font-size: 16px; vertical-align: baseline; white-space: pre-wrap;">От нас требовалось разработать концепцию дизайна. </span></span></span></p>\r\n\r\n<p style="text-align: center;"><span><span style="font-size: 16px; font-family: Arial; vertical-align: baseline; white-space: pre-wrap;">Мы воссоздали &nbsp;интерьер для комфортного отдыха, который придется по вкусу каждому посетителю отеля. Всё выполнено в характерном классическом стиле. Колонны с бронзовыми капителями очень органично дополняют классический интерьер. Отделка стен осуществляется однотонной декоративной штукатуркой, помимо этого стены дополнительно украшаются оригинальными картинами и стильными принтами. Важные составляющие образа интерьера это спокойные и благородные тона. Детали, применяемые в отделке стен- лепка. Также в оформлении &nbsp;наши специалисты делают ставку на материалах с необычной фактурой, авторские уникальные изделия из дерева, стекла и камня. В целом получился функциональный интерьер с легким ненавязчивым декором. Стиль отражает желаемую простоту и одновременно формирует особый характер пространства.</span></span><img alt="" src="/upload/image/img_8995.jpg" style="font-family: ProximaNova, \'Open Sans\', Helvetica, sans-serif; font-size: 16px; line-height: 20.8px;" /><img alt="" src="/upload/image/img_9006.jpg" style="font-family: ProximaNova, \'Open Sans\', Helvetica, sans-serif; font-size: 16px; line-height: 20.8px;" /><img alt="" src="/upload/image/img_8999.jpg" style="font-family: ProximaNova, \'Open Sans\', Helvetica, sans-serif; font-size: 16px; line-height: 20.8px;" /></p>\r\n', 'IMG_9005.jpg', 0, '', 1, 0, 0, '', '', NULL, '2015-12-23 11:52:39', '2016-01-22 09:25:25');

-- --------------------------------------------------------

--
-- Структура таблицы `rates`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `rates`;
CREATE TABLE `rates` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `position` smallint(6) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `requests`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `requests`;
CREATE TABLE `requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `title`, `value`, `created_at`, `updated_at`) VALUES
(1, 'title', 'title', 'Дизайн квартиры в спб | Дизайн интерьера дома - Asafov design', '0000-00-00 00:00:00', '2015-12-11 11:24:03'),
(2, 'phone_head', 'Телефон в шапке', '<span>812 </span> 649-04-04', '0000-00-00 00:00:00', '2015-12-10 09:07:57'),
(3, 'email_head', 'email в шапке', 'info@asafov.design', '0000-00-00 00:00:00', '2015-12-10 05:36:00'),
(4, 'email', 'email для отправки формы', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `sliders`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `sliders`;
CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `button` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `types`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `types`;
CREATE TABLE `types` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `position` smallint(6) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `types`
--

INSERT INTO `types` (`id`, `type`, `name`, `template`, `title`, `text`, `status`, `position`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'page', 'Страница', 'page', 'Дизайн интерьера дома | Дизайн квартиры - Asafov Design', '<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-d38a715f-b0a8-5be1-9b9c-a723718dd904"><span style="font-size: 13.3333px; font-family: Arial; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap;">Главное направления деятельности Asafov design &mdash; это архитектурные проекты, ландшафтное проектирование и дизайн интерьеров. Для нас нет невыполнимых задач, мы знаем, как сочетать качество и креатив! </span></span></p>\r\n\r\n<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-d38a715f-b0a8-5be1-9b9c-a723718dd904"><span style="font-size: 13.3333px; font-family: Arial; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap;">В наш творческий процесс входит проектирование индивидуальных жилых интерьеров и объектов городской среды. Мы успешно реализовали такие объекты как: парки, городские районы, интерьеры квартир, частные дома, офисы и бизнес-центры. Сотрудничество с нами обеспечивает высококачественное проектирование объектов,контроль реализации проектов и оптимизацию сроков их выполнения. </span><span style="font-size: 13.3333px; font-family: Arial; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: rgb(251, 251, 251);">Наша команда состоит из </span></span></p>\r\n\r\n<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-d38a715f-b0a8-5be1-9b9c-a723718dd904"><span style="font-size: 13.3333px; font-family: Arial; color: rgb(0, 0, 0); vertical-align: baseline; white-space: pre-wrap; background-color: rgb(251, 251, 251);">высококвалифицированных специалистов &nbsp;в области дизайна интерьера, архитектуры и проектирования. </span></span></p>\r\n\r\n<div>&nbsp;</div>\r\n', 0, 0, NULL, '0000-00-00 00:00:00', '2015-12-22 10:18:37'),
(2, 'services', 'Услуги', 'page', 'Дизайн интерьера интерьера в Санкт-Петербурге| Услуги дизайнера интерьера| дизайнер интерьера - Asafov Design', '<h1 dir="ltr" style="margin: 10px 0px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: bold; line-height: 40px; text-rendering: optimizeLegibility; font-size: 38.5px;">Наши услуги.</h1>\r\n\r\n<h2 style="margin: 10px 0px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: bold; line-height: 40px; text-rendering: optimizeLegibility; font-size: 31.5px;"><img alt="" data-mce-src="http://asafov.design/upload/image/1449690289_checklist.png" src="http://asafov.design/upload/image/1449690289_checklist.png" style="max-width: 100%; height: auto; vertical-align: middle; border: 0px;" />&nbsp;&nbsp; Составление технического задания.</h2>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; text-align: justify; text-indent: 18.75pt; line-height: 18.4pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">На первом этапе подготавливается техническая планировка&nbsp;будущего дизайна интерьера. Дизайнер&nbsp;должен&nbsp;ознакомиться со вкусами всех&nbsp;членов&nbsp;семьи,&nbsp;выяснить&nbsp;привычки и&nbsp;пристрастия,&nbsp; понять образ жизни, который ведет семья.&nbsp;Этот шаг считается принципиальным.&nbsp;Поэтому, &nbsp;чем&nbsp;больше информации вы предоставите&nbsp; дизайнеру,&nbsp;тем точнее дизайнер сможет&nbsp;осуществить вашу мечту об идеальном доме&nbsp;и&nbsp;добиться желаемого.&nbsp;<o:p></o:p></p>\r\n\r\n<h2 dir="ltr" style="margin: 10px 0px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: bold; line-height: 40px; text-rendering: optimizeLegibility; font-size: 31.5px;"><img alt="" data-mce-src="http://asafov.design/upload/image/1449690354_stage.png" src="http://asafov.design/upload/image/1449690354_stage.png" style="max-width: 100%; height: auto; vertical-align: middle; border: 0px;" />&nbsp;&nbsp;&nbsp; 3D визуализация&nbsp;всех помещений в 2&ndash;3 стилях.</h2>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; text-align: justify; text-indent: 18.75pt; line-height: 18.4pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Проводится моделирование объекта на основе планировочных решений. Благодаря эскизам вы реалистично увидите интерьер помещения со всех возможных ракурсов. Во время 3D визуализации происходит&nbsp;оживление&nbsp;моделей характерными бытовыми атрибутами, просчитывается изображение в высоком разрешении (для высококачественной полиграфии), производится цветовая коррекция, используются световые эффекты.<o:p></o:p></p>\r\n\r\n<h2 dir="ltr" style="margin: 10px 0px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: bold; line-height: 40px; text-rendering: optimizeLegibility; font-size: 31.5px;"><img alt="" data-mce-src="http://asafov.design/upload/image/1449690591_streamline_29.png" src="http://asafov.design/upload/image/1449690591_streamline_29.png" style="max-width: 100%; height: auto; vertical-align: middle; border: 0px;" />&nbsp;&nbsp; Эскизное проектирование</h2>\r\n\r\n<p style="margin: 0cm 0cm 7.5pt; text-align: justify; text-indent: 18.75pt; line-height: 18.4pt; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">Важным этапом эскизного проектирования является определение технических характеристик дома и стилистического направления дизайна. Всё это согласовывается с клиентом, учитывая его вкусовые предпочтения.&nbsp;<o:p></o:p></p>\r\n\r\n<h3 dir="ltr" style="margin: 10px 0px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: bold; line-height: 40px; text-rendering: optimizeLegibility; font-size: 24.5px;">Задачи эскизного проектирования:</h3>\r\n\r\n<ul dir="ltr" style="padding-right: 0px; padding-left: 0px; margin: 0px 0px 10px 25px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 24.5px;">\r\n	<li style="line-height: 20px;">Укрупнённая ведомость строительных материалов, объёмов и площадей;</li>\r\n	<li style="line-height: 20px;">Генеральный план участка;</li>\r\n	<li style="line-height: 20px;">Схема расстановки мебели;</li>\r\n	<li style="line-height: 20px;">План сантехнического оборудования и точек вывода канализации;</li>\r\n	<li style="line-height: 20px;">План привязки электроосвещения и электротехнических приборов;</li>\r\n</ul>\r\n\r\n<h2 dir="ltr" style="margin: 10px 0px; font-family: Candara, \'Open Sans\', \'Helvetica Neue\', Helvetica, Arial, sans-serif; font-weight: bold; line-height: 40px; text-rendering: optimizeLegibility; font-size: 31.5px;"><img alt="" data-mce-src="http://asafov.design/upload/image/1449690660_streamline_61.png" src="http://asafov.design/upload/image/1449690660_streamline_61.png" style="max-width: 100%; height: auto; vertical-align: middle; border: 0px;" />&nbsp; Авторский надзор.</h2>\r\n\r\n<p>Авторский надзор подразумевает контроль дизайнера за строительством, закупкой материалов и мебели. Это способствует хорошей экономии. Во время авторского надзора ведётся журнал, в который вносятся все замечания и пожелания дизайнера.</p>\r\n\r\n<p>&nbsp;В авторский надзор входит:&nbsp;</p>\r\n\r\n<ul>\r\n	<li>&nbsp;Выезд дизайнера на объект.</li>\r\n	<li>&nbsp;Консультация и контроль над соблюдением выполнения дизайн-проекта.</li>\r\n	<li>&nbsp;Корректировка рабочих чертежей</li>\r\n	<li>Дизайн ландшафта;</li>\r\n</ul>\r\n\r\n<p>Ландшафт - это тесное воссоединение архитектуры с природой. Правильно подобранный дизайн&nbsp;становится частью имиджа и визитной карточкой &nbsp;владельца.</p>\r\n', 1, 0, NULL, '0000-00-00 00:00:00', '2015-12-21 06:55:59'),
(3, 'styles', 'Стили', 'style', 'Стиль в дизайне интерьера| Дизайн в квартире - Asafov Design', '', 1, 0, NULL, '0000-00-00 00:00:00', '2015-12-11 12:32:38'),
(4, 'news', 'Новости', 'news', 'Новости в дизайне интерьера | Asafov Design', '', 1, 0, NULL, '0000-00-00 00:00:00', '2015-12-23 11:51:03'),
(5, 'price', 'Стоимость', 'page', 'Стоимость дизайна интерьера квартиры спб| офиса|дома| яхты|самолета - Asafov Design', '<style type="text/css">td span{color:#ff9000;}\r\n</style>\r\n<article id="price">\r\n<h1 style="text-align: center;">&nbsp;Стоимость &nbsp;</h1>\r\n\r\n<hr class="line" />\r\n<p><span style="font-size:16px;">В данной таблице Вы можете ознакомиться с полным перечнем &nbsp;услуг архитектурной мастерской. Окончательная цена, количество вариантов и сроки исполнения обговариваются индивидуально. Чтобы получить больше информации&nbsp;звоните нам по телефону: 649-04-04</span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table class="table table-striped">\r\n	<tbody>\r\n		<tr>\r\n			<th>&nbsp;</th>\r\n			<th>Эскизный</th>\r\n			<th>Стандарт</th>\r\n			<th>Максимум</th>\r\n			<th>Максимум+</th>\r\n		</tr>\r\n		<tr>\r\n			<td>Обмерный план</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Составление технического задания</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>План расстановки мебели в 7-8 вариантах</td>\r\n			<td style="text-align: center;"><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;<strong>✔</strong></span></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>3D визуализации всех помещений в 2-3 стилях</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Полный комплект рабочей документации для строителей</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;<strong>✔</strong></span></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Составление бюджета на проект</td>\r\n			<td>&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Подбор финишных отделочных материалов,сантехники, мебели</td>\r\n			<td>&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Интеграция инженерного оборудования в дизайн-проект</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Развертка стен</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Декорирование интерьера</td>\r\n			<td>&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Работа с заказными изделиями,заказ, надзор за исполнением</td>\r\n			<td>&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Выезд дизайнера вместе с Вами в салоны поставщиков</td>\r\n			<td>&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<td>Авторский надзор</td>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n			<td style="text-align: center;">&nbsp;</td>\r\n			<td style="text-align: center;"><strong><span style="font-family: Arial, Helvetica, sans-serif; line-height: 17px;">&nbsp;✔</span></strong></td>\r\n		</tr>\r\n		<tr>\r\n			<th>Стоимость</th>\r\n			<th>от 600 р/м.кв</th>\r\n			<th>от 1000 р/м.кв</th>\r\n			<th>от 1500 р/м.кв</th>\r\n			<th>от 3000 р/м.кв</th>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n</article>\r\n', 1, 0, NULL, '0000-00-00 00:00:00', '2015-12-23 06:16:35'),
(6, 'works', 'Наши работы', 'portfolio', 'Работы Asafov Design| Дизайн интерьера| 3D визуализация', '<h1 style="text-align: center;">Наши работы</h1>\r\n\r\n<p style="text-align: center;">&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 1, 0, NULL, '0000-00-00 00:00:00', '2015-12-22 07:45:07'),
(7, 'contacts', 'Контакты', 'page', 'Контакты Asafov Design| телефон Асафов дизайн|адрес офиса Asafov Design', '<p style="text-align: center;"><img alt="" src="/upload/image/logoas.png" style="width: 289px; height: 79px;" /></p>\r\n\r\n<h1 style="text-align: center;"><span style="font-size:16px;">Наши контакты:</span></h1>\r\n\r\n<p style="text-align: center;">Мы находимся по адресу<br />\r\nНаб. Реки Мойки,&nbsp;7<br />\r\nЗдание корпорации PMI</p>\r\n\r\n<p style="text-align: center;"><br />\r\nТелефон:<a href="tel:+8126490404"><span style="color:#FF8C00;">812&nbsp;649-04-04&nbsp;</span></a><br />\r\nE-mail:&nbsp;<a href="mailto:info@asafov.design"><span style="color:#FF8C00;">info@asafov.design</span></a></p>\r\n<script type="text/javascript" charset="utf-8" src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=ruD8dZUV72WJ9n2k-Sa0PVU5zU6Z9jPO&height=263&lang=ru_RU&sourceType=constructor"></script>', 1, 0, NULL, '0000-00-00 00:00:00', '2015-12-14 11:50:33');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Дек 02 2015 г., 14:56
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `activationCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `name`, `password`, `remember_token`, `isActive`, `activationCode`, `description`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'super@admin.my', 'SuperAdmin', '$2y$10$87FKGrtbde/O6CCW2Fuxgux/lcdZmWdrV8.a9xG4/yyAU1mfl4VPS', 'dggk0RYmuGNJ8HAdfjwEDxD2Mru5TLqKAQGhBUAZoY277Smc6lGdZVFAQLhW', 1, '', '', 1, NULL, '2015-11-23 13:15:34', '2015-11-24 19:12:13');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_reminders`
--
ALTER TABLE `password_reminders`
  ADD KEY `password_reminders_email_index` (`email`),
  ADD KEY `password_reminders_token_index` (`token`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rates`
--
ALTER TABLE `rates`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT для таблицы `rates`
--
ALTER TABLE `rates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `types`
--
ALTER TABLE `types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
